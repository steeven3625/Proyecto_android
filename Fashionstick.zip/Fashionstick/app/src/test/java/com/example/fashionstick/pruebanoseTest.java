package com.example.fashionstick;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class pruebanoseTest {
    @Test
    public void testSacarprecio() {
        pruebanose sacarprecio = new pruebanose();
        double precio = sacarprecio.SacarPrecio("Precio: $9.99");
        assertEquals(9.99, precio, 0.01);
    }
    @Test
    public void testSacarprecio2() {
        pruebanose sacarprecio = new pruebanose();
        double precio2 = sacarprecio.SacarPrecio("Precio: $8.00");
        assertEquals(9.99, precio2, 0.01);
    }
}