package com.example.fashionstick;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CarritocomprasTest {
    @Test
    public void testSacarprecio() {
        pruebanose sacarprecio = new pruebanose();
        double precio = sacarprecio.SacarPrecio("Precio: $9.000");
        assertEquals(9.000, precio, 0.01);
    }
    @Test
    public void testSacarprecio2() {
        pruebanose sacarprecio = new pruebanose();
        double precio2 = sacarprecio.SacarPrecio("Precio: $8.000");
        assertEquals(9.000, precio2, 0.01);
    }
}