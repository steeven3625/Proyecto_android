package com.example.fashionstick;

public class nueva_coleccion_item {

    int imagen;
    String titulo;

    public nueva_coleccion_item(int imagen, String titulo) {
        this.imagen = imagen;
        this.titulo = titulo;
    }

    public int getImagen() {
        return imagen;
    }

    public String getTitulo() {
        return titulo;
    }
}
