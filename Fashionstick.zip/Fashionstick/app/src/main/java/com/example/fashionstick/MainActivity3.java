package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class MainActivity3 extends AppCompatActivity {
    EditText name, user, correo, phone, pass;
    Button registro;
    private FirebaseAuth mAuth;
    FirebaseDatabase rootNode;
    DatabaseReference reference;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        mAuth = FirebaseAuth.getInstance();
        name = findViewById(R.id.nombre);
        user = findViewById(R.id.usuario);
        correo = findViewById(R.id.email);
        phone = findViewById(R.id.telefono);
        pass = findViewById(R.id.contrasenas);
        registro = findViewById(R.id.regresar_main);

        registro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(i);
            }
        });

    }

    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
    }

    public void RegistrarUsuario(View v) {
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("usuarios");
        String name_db = name.getText().toString();
        String user_db = user.getText().toString();
        String email_db = correo.getText().toString();
        String phone_db = phone.getText().toString();
        String pass_db = pass.getText().toString();


        //DATABASE
        database_users bdusu = new database_users(name_db, user_db, email_db, phone_db, pass_db);
        reference.child(phone_db).setValue(bdusu);

        //Autenticacion
        mAuth.createUserWithEmailAndPassword(correo.getText().toString(), pass.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                        }
                    }
                });
        mAuth.createUserWithEmailAndPassword(phone.getText()+"@jshdaacml.com".toString(), pass.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                        }
                    }
                });
        mAuth.createUserWithEmailAndPassword(user.getText() + "@jshdaacml.com".toString(), pass.getText().toString())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Usuario registrado.", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent i = new Intent(getApplicationContext(), MainActivity4.class);
                            startActivity(i);
                        } else {
                            Toast.makeText(getApplicationContext(), "Hubo un error.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}