package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class phone_forgot extends AppCompatActivity {

    Button enviarnumero1;
    EditText rellenar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_forgot);
        enviarnumero1 = findViewById(R.id.enviarnumero);
        rellenar = findViewById(R.id.cualquiercosa12);


    }
    public void validar(View view){
        String number1 = (rellenar.getText().toString());
        String _numero = rellenar.getText().toString().trim();
        if(_numero.charAt(0)==0){
            _numero = _numero.substring(1);
        }
        String _numerocompleto = _numero;

        Query checkUser = FirebaseDatabase.getInstance().getReference("usuarios").orderByChild("phone_db").equalTo(_numerocompleto);
        checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    rellenar.setError(null);
                    rellenar.setEnabled(false);

                    Intent i = new Intent(getApplicationContext(), Codigo_veri.class);
                    i.putExtra("phoneNo",_numerocompleto);
                    i.putExtra("new","actualizar");
                    i.putExtra("resul",number1);
                    startActivity(i);
                    finish();

                }else{
                    rellenar.setError("No existe");
                    rellenar.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}