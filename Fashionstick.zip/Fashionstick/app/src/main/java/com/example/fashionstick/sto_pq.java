package com.example.fashionstick;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class sto_pq extends RecyclerView.Adapter<sto_pq.mirar2>{
    ArrayList<modelo> locacion3;

    public sto_pq(ArrayList<modelo> locacion3) {
        this.locacion3 = locacion3;
    }

    @NonNull
    @Override
    public mirar2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.modelo_diseno, parent, false);
        mirar2 traer = new mirar2(view);
        return traer;
    }

    @Override
    public void onBindViewHolder(@NonNull mirar2 holder, int position) {
        modelo items = locacion3.get(position);
        holder.Asunto.setText(items.getAsunto());
        holder.Descripcion.setText(items.getDescripcion());
    }

    @Override
    public int getItemCount() {

        return locacion3.size();
    }

    public static class mirar2 extends RecyclerView.ViewHolder {

        TextView Asunto;
        TextView Descripcion;
        public mirar2(@NonNull View itemView) {
            super(itemView);
            Asunto = itemView.findViewById(R.id.asunto);
            Descripcion = itemView.findViewById(R.id.descripc);
        }
    }
}
