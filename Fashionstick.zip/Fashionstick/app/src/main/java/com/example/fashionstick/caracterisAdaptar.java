package com.example.fashionstick;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class caracterisAdaptar extends RecyclerView.Adapter<caracterisAdaptar.mirar> {
    ArrayList<nueva_coleccion_item> locacion;

    public caracterisAdaptar(ArrayList<nueva_coleccion_item> locacion) {
        this.locacion = locacion;
    }

    @NonNull
    @Override
    public mirar onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.diseno_nuevo, parent, false);
        mirar traer = new mirar(view);
        return traer;
    }

    @Override
    public void onBindViewHolder(@NonNull mirar holder, int position) {
        nueva_coleccion_item items = locacion.get(position);
        holder.imagen.setImageResource(items.getImagen());
        holder.titulo.setText(items.getTitulo());
    }

    @Override
    public int getItemCount() {

        return locacion.size();
    }

    public static class mirar extends RecyclerView.ViewHolder {

        ImageView imagen;
        TextView titulo;

        public mirar(@NonNull View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imagen1);
            titulo = itemView.findViewById(R.id.camisas);
        }
    }
}
