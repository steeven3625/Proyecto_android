package com.example.fashionstick;

public class pruebanose {

    public double SacarPrecio(String precioText) {
        String[] parts = precioText.split(": ");
        String precioString = parts[1].substring(1);
        return Double.parseDouble(precioString);
    }
}