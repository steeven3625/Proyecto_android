package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class Codigo_veri extends AppCompatActivity {

    TextView mostrar_numero;
    EditText ingresar_code;
    String numerodetelefono;
    FirebaseAuth mAuth;
    String codigo;
    Button xd,xd1;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_codigo_veri);

        mostrar_numero = findViewById(R.id.numerotelefono);
        ingresar_code = findViewById(R.id.cualquiercosa12);
        xd= findViewById(R.id.boton_teste);
        xd1= findViewById(R.id.BotonVerificador);
        mAuth = FirebaseAuth.getInstance();

        mAuth.setLanguageCode("es");
        numerodetelefono = getIntent().getStringExtra("phoneNo");
        String resultado = getIntent().getStringExtra("resul");
        mostrar_numero.setText("Te hemos enviado un mensaje de texto con un código al número <b>" + resultado +
                "</b>, por favor ingresa el código de verificación de 6 dígitos");
        mostrar_numero.setText(Html.fromHtml("Te hemos enviado un mensaje de texto con un código al número <b>" + resultado +
                "</b>, por favor ingresa el código de verificación de 6 dígitos."));
        xd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = "+573112448340";
                if (!phoneNumber.isEmpty()) {
                    PhoneAuthOptions options =
                            PhoneAuthOptions.newBuilder(mAuth)
                                    .setPhoneNumber(phoneNumber)       // Phone number to verify
                                    .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                                    .setActivity(Codigo_veri.this)                 // Activity (for callback binding)
                                    .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                                    .build();
                    PhoneAuthProvider.verifyPhoneNumber(options);
                } else {
                }
            }});
            mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                @Override
                public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                    //Iniciamos sesion
                    String code = phoneAuthCredential.getSmsCode();
                    if (code != null) {
                        verifycode(code);
                    }
                }

                @Override
                public void onVerificationFailed(@NonNull FirebaseException e) {
                    //Falló el inicio de sesion
                }

                @Override
                public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                    super.onCodeSent(s, forceResendingToken);
                    codigo = s;
                }
            };
        xd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String codigoVerificacio = ingresar_code.getText().toString();

                if(!codigoVerificacio.isEmpty()){
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential
                            (codigo, codigoVerificacio);
                    iniciar(credential);
            }else{
                    Toast.makeText(Codigo_veri.this,"Malo",Toast.LENGTH_SHORT).show();
                }
            }});

        }
        private void verifycode (String code) {

                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(codigo, code);
                iniciar(credential);
            }


    private void iniciar (PhoneAuthCredential credential){

        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        firebaseAuth.signInWithCredential(credential)

                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Metodocambiar();
                            Toast.makeText(Codigo_veri.this, "Si se pudo", Toast.LENGTH_SHORT).show();
                        } else {
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                Toast.makeText(Codigo_veri.this, "No se pudo", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }

    private void Metodocambiar () {
        Intent intenta = new Intent((getApplicationContext()), Restablecer_clave.class);
        intenta.putExtra("phoneNo", numerodetelefono);
        startActivity(intenta);
        finish();
    }

}
