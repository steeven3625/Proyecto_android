package com.example.fashionstick;

public class modelo {
    String id, asunto, descripcion;
    public modelo(){
    }

    public modelo(String id, String asunto, String descripcion) {
        this.id = id;
        this.asunto = asunto;
        this.descripcion = descripcion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
