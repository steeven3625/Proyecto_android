package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity4 extends AppCompatActivity {
    private ViewPager pagina;
    RecyclerView.Adapter _adaptador;
    RecyclerView _nuevacoleccion;
    RecyclerView _nuevacoleccion1;
    Button categorias1;
    private int paginaactual = 0;
    private FirebaseAuth mAuth;
    private int NUM_PAGES = 3;
    private int[] imagenes = {R.drawable.banner5, R.drawable.banner6, R.drawable.banner8};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        pagina = findViewById(R.id.banner);
        _nuevacoleccion = findViewById(R.id.nuevacoleccion);
        _nuevacoleccion1 = findViewById(R.id.categories_tabla);
        categorias1= findViewById(R.id.boton_categorias);
        _nuevacoleccion();
        _nuevacoleccion1();
        pagina.setAdapter(new ImagenAdaptar(this, imagenes));
        mAuth = FirebaseAuth.getInstance();
        Button signOutButton = findViewById(R.id.cerrarsesion);
        categorias1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent asd = new Intent(MainActivity4.this, Categorias.class);
                startActivity(asd);
            }
        });
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                Toast.makeText(MainActivity4.this, "Sesión cerrada", Toast.LENGTH_SHORT).show();

            }
        });
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (paginaactual == NUM_PAGES + 1) {
                            paginaactual = 0;
                        }
                        pagina.setCurrentItem(paginaactual++, true);
                    }
                });
            }
        }, 3000, 3000);
    }

    private void _nuevacoleccion() {

        _nuevacoleccion.setHasFixedSize(true);
        _nuevacoleccion.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));

        ArrayList<nueva_coleccion_item>location = new ArrayList<>();

        location.add(new nueva_coleccion_item(R.drawable.mujer5,"VESTIDOS"));
        location.add(new nueva_coleccion_item(R.drawable.mujer6,"KIMONOS"));
        location.add(new nueva_coleccion_item(R.drawable.mujer7,"LANA ROSA"));
        location.add(new nueva_coleccion_item(R.drawable.mujer8,"CAMISETAS"));
        location.add(new nueva_coleccion_item(R.drawable.mujer9,"ACCESORIOS"));
        _adaptador= new caracterisAdaptar(location);
        _nuevacoleccion.setAdapter(_adaptador);

    }
    private void _nuevacoleccion1() {


        _nuevacoleccion1.setHasFixedSize(true);
        _nuevacoleccion1.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));

        ArrayList<recibir_data2>locacion2 = new ArrayList<>();
        locacion2.add(new recibir_data2(R.drawable.banner,"HOMBRES"));
        locacion2.add(new recibir_data2(R.drawable.banne2,"MUJERES"));
        locacion2.add(new recibir_data2(R.drawable.banner3,"NIÑOS"));
        _adaptador= new categorias_sto(locacion2);
        _nuevacoleccion1.setAdapter(_adaptador);
_nuevacoleccion1.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
    _nuevacoleccion1.setHasFixedSize(true);
    }
    public void ircarrito(View view) {
        Intent intent = new Intent(this, Carritocompras.class);
        startActivity(intent);
    }
    public void quejas(View view) {
        Intent intent = new Intent(this, pqrs.class);
        startActivity(intent);
    }
}

