package com.example.fashionstick;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class clave_success extends AppCompatActivity {
    Button inicio1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clave_success);

        inicio1 = findViewById(R.id.volver_inicio);

        inicio1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent da = new Intent(clave_success.this, MainActivity2.class);
                startActivity(da);
                finish();
            }
        });
    }
}