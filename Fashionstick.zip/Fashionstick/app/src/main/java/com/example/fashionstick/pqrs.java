package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class pqrs extends AppCompatActivity {

    EditText titulo1, descrip;
    Button enviar,iralista;
    ProgressDialog msg;
    FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pqrs);
        titulo1= findViewById(R.id.titulo);
        descrip= findViewById(R.id.descripcion);
        enviar= findViewById(R.id.enviar_basededatos);
        iralista = findViewById(R.id.mostrarpqrs);
        msg = new ProgressDialog(this);
        db = FirebaseFirestore.getInstance();

        iralista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ia = new Intent(pqrs.this, MainActivity6.class);
                startActivity(ia);
            }
        });
        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String titulo = titulo1.getText().toString().trim();
                String descripcion = descrip.getText().toString().trim();
                actualizar (titulo, descripcion);
            }
        });
    }

    private void actualizar(String titulo, String descripcion) {
        msg.setTitle("Enviando");
        msg.show();
        String id = UUID.randomUUID().toString();
        Map<String,Object> pqrs = new HashMap<>();
        pqrs.put("id", id);
        pqrs.put("Asunto", titulo);
        pqrs.put("Descripcion", descripcion);
        db.collection("PQRS").document(id).set(pqrs)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                msg.dismiss();
                Toast.makeText(pqrs.this,"Enviado",Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        msg.dismiss();
                        Toast.makeText(pqrs.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });
    }
}