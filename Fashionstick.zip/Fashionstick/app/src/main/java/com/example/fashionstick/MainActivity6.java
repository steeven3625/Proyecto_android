package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MainActivity6 extends AppCompatActivity {

    RecyclerView _list;
    RecyclerView.Adapter _adaptador;
    FirebaseFirestore db;
    ProgressDialog msg;
    Button lol;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        _list= findViewById(R.id.listap);
        db = FirebaseFirestore.getInstance();
        lol = findViewById(R.id.botonxd);

        lol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db.collection("PQRS")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {
                                    Log.d("MainActivity6", "Botón LOL clickeado");
                                    ArrayList<modelo> listaModelos = new ArrayList<>();
                                    for (DocumentSnapshot doc : task.getResult()) {
                                        modelo model = new modelo(doc.getString("id"),
                                                doc.getString("Asunto"),
                                                doc.getString("Descripcion"));
                                        listaModelos.add(model);
                                    }
                                    _adaptador = new sto_pq(listaModelos);
                                    _list.setAdapter(_adaptador);
                                } else {
                                    Toast.makeText(MainActivity6.this, "Error al obtener datos", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                }
            });

    }
}