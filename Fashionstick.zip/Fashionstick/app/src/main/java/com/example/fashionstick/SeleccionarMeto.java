package com.example.fashionstick;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SeleccionarMeto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccionar_meto);
    }
    public void selecciontelefono (View v){
        Intent i = new Intent(this, phone_forgot.class);
        startActivity(i);
    }
    public void seleccioncorreo (View v){
        Intent i = new Intent(this, olvideclave.class);
        startActivity(i);
    }
}