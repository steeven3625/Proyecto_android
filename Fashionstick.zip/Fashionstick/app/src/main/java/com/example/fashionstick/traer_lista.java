package com.example.fashionstick;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class traer_lista extends RecyclerView {
    TextView titilo, descripcion;
    View mirar3;
    public traer_lista (@NonNull View itemView){
        super(itemView.getContext());

        mirar3 = itemView;

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mClickListener.OnItemClick(v, getAdapter().getItemCount());
            }
        });
        itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mClickListener.OnItemLongClick(v, getAdapter().getItemCount());
                return true;
            }
        });
        titilo = itemView.findViewById(R.id.asunto);
        descripcion = itemView.findViewById(R.id.descripc);
    }
    private traer_lista.ClickListener mClickListener;
    public interface ClickListener{
        void OnItemClick(View view, int position);
        void OnItemLongClick(View view, int position);
    }
    public void setOnClickListener(traer_lista.ClickListener clicklistener){
        mClickListener = clicklistener;
    }

}
