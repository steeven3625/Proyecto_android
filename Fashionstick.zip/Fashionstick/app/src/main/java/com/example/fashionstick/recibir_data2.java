package com.example.fashionstick;

public class recibir_data2 {

    int imagenx;
    String titulox;

    public recibir_data2(int imagen2, String titulo2) {
        this.imagenx = imagen2;
        this.titulox = titulo2;
    }

    public int getImagen() {
        return imagenx;
    }

    public String getTitulo() {
        return titulox;
    }
}
