package com.example.fashionstick;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Categorias extends AppCompatActivity {

    Button mujer,hombre,nino;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorias);
        mujer = findViewById(R.id.categoria_mujer);
        hombre = findViewById(R.id.categoria_hombre);
        nino = findViewById(R.id.categoria_nino);

        mujer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Categorias.this, Mujer.class);
                startActivity(i);
            }
        });
        hombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Categorias.this, Hombre.class);
                startActivity(i);
            }
        });
        nino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Categorias.this, Ninos.class);
                startActivity(i);
            }
        });
    }
}