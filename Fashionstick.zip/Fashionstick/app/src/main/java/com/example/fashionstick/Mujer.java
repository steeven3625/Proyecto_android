package com.example.fashionstick;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Mujer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mujer);
    }
}