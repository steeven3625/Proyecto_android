package com.example.fashionstick;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Carritocompras extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carritocompras);

        TextView pprecio1 = findViewById(R.id.precio1);
        TextView pprecio2 = findViewById(R.id.precio2);
        double producto1 = SacarPrecio(pprecio1.getText().toString());
        double producto2 = SacarPrecio(pprecio2.getText().toString());

        double preciototal = producto1 + producto2;

        TextView Total = findViewById(R.id.preciodef);
        Total.setText("Precio total: " + (preciototal));
    }

    public double SacarPrecio(String precioText) {
        String[] parts = precioText.split(": ");
        String precioString = parts[1].substring(1);
        return Double.parseDouble(precioString);
    }

    }

