package com.example.fashionstick;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Restablecer_clave extends AppCompatActivity {
    Button boton_restablecer;
    EditText new_pass;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restablecer_clave);
        boton_restablecer = findViewById(R.id.siguiente_restablecer);
        new_pass = findViewById(R.id.nuevacontrasena);

        boton_restablecer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _nuevaclave = new_pass.getText().toString().trim();
                String _telefono= getIntent().getStringExtra("phoneNo");
                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("usuarios");
                reference.child(_telefono).child("pass_db").setValue(_nuevaclave);
                startActivity(new Intent(getApplicationContext(),clave_success.class));
                finish();
            }
        });
    }
}