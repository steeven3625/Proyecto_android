package com.example.fashionstick;

public class database_users {
    String name_db,user_db,email_db,phone_db,pass_db;
    public database_users (){

    }
    public database_users(String name_db, String user_db, String email_db, String phone_db, String pass_db) {
        this.name_db = name_db;
        this.user_db = user_db;
        this.email_db = email_db;
        this.phone_db = phone_db;
        this.pass_db = pass_db;
    }

    public String getName_db() {
        return name_db;
    }

    public void setName_db(String name_db) {
        this.name_db = name_db;
    }

    public String getUser_db() {
        return user_db;
    }

    public void setUser_db(String user_db) {
        this.user_db = user_db;
    }

    public String getEmail_db() {
        return email_db;
    }

    public void setEmail_db(String email_db) {
        this.email_db = email_db;
    }

    public String getPhone_db() {
        return phone_db;
    }

    public void setPhone_db(String phone_db) {
        this.phone_db = phone_db;
    }

    public String getPass_db() {
        return pass_db;
    }

    public void setPass_db(String pass_db) {
        this.pass_db = pass_db;
    }
}
