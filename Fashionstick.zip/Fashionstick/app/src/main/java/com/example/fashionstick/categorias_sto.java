package com.example.fashionstick;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class categorias_sto extends RecyclerView.Adapter<categorias_sto.mirar2>{
    ArrayList<recibir_data2> locacion2;

    public categorias_sto(ArrayList<recibir_data2> locacion2) {
        this.locacion2 = locacion2;
    }

    @NonNull
    @Override
    public mirar2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.categorias_diseno, parent, false);
        mirar2 traer = new mirar2(view);
        return traer;
    }

    @Override
    public void onBindViewHolder(@NonNull mirar2 holder, int position) {
        recibir_data2 items = locacion2.get(position);
        holder.imagen.setImageResource(items.getImagen());
        holder.titulo.setText(items.getTitulo());
    }

    @Override
    public int getItemCount() {

        return locacion2.size();
    }

    public static class mirar2 extends RecyclerView.ViewHolder {

        ImageView imagen;
        TextView titulo;

        public mirar2(@NonNull View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imagen2);
            titulo = itemView.findViewById(R.id.categorias2);
        }
    }
}
