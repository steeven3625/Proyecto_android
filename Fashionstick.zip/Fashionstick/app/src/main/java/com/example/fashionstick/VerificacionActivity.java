package com.example.fashionstick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class VerificacionActivity extends AppCompatActivity {
    EditText poner1,poner2,poner3,poner4,poner5,poner6;


    Button mButtonVerificar;

    FirebaseAuth mAuth;
    String intenAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verificacion);

        poner1 = findViewById(R.id.codigo1);
        poner2 = findViewById(R.id.codigo2);
        poner3 = findViewById(R.id.codigo3);
        poner4 = findViewById(R.id.codigo4);
        poner5 = findViewById(R.id.codigo5);
        poner6 = findViewById(R.id.codigo6);

        pasar_siguiente(poner1, poner2);
        pasar_siguiente(poner2, poner3);
        pasar_siguiente(poner3, poner4);
        pasar_siguiente(poner4, poner5);
        pasar_siguiente(poner5, poner6);
        mButtonVerificar = findViewById(R.id.verificaciondenumero);

        mAuth = FirebaseAuth.getInstance();

        intenAuth = getIntent().getStringExtra("auth");


        mButtonVerificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String codigoVerificacio = poner1.getText().toString()+poner2.getText().toString()+poner3.getText().toString()+poner4.getText().toString()
                        +poner5.getText().toString()+poner6.getText().toString();

                if(!codigoVerificacio.isEmpty()){
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential
                            (intenAuth, codigoVerificacio);
                    iniciarSesion(credential);
                }else{
                    Toast.makeText(VerificacionActivity.this, "Ingrese el codigo de verificacion", Toast.LENGTH_SHORT).show();
                }
            }

            private void iniciarSesion(PhoneAuthCredential credential) {
                mAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            inicioActivityHome();
                        }else{
                            Toast.makeText(VerificacionActivity.this, "Error de verifición", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }

    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null){
            inicioActivityHome();
        }
    }

    private void inicioActivityHome() {
        Intent intent = new Intent(VerificacionActivity.this, MainActivity4.class);
        startActivity(intent);
        finish();
    }
    private void pasar_siguiente(final EditText casilla_actual, final EditText siguiente) {
        casilla_actual.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 1) {
                    siguiente.requestFocus();
                }
            }
        });
    }
}

